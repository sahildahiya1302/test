CREATE DATABASE website_db;

USE website_db;

CREATE TABLE articles (
    id VARCHAR(255) PRIMARY KEY,
    title VARCHAR(255),
    excerpt TEXT,
    image VARCHAR(255),
    date DATE,
    author VARCHAR(255),
    content TEXT,
    category VARCHAR(255)
);
