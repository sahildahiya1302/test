/**
 * TodayLive - Homepage JavaScript
 * Handles article loading and display
 */

// Configuration
const CATEGORIES = ['news', 'sport', 'lifestyle', 'technology', 'business'];

// Main initialization
document.addEventListener('DOMContentLoaded', () => {
    loadAndDisplayArticles();
});

// Core article loading function
async function loadAndDisplayArticles() {
    showLoading();
    try {
        const articles = await loadArticles();
        if (articles.length > 0) {
            renderArticles(articles);
            setupFilters();
            setupSearch();
        } else {
            showError('No articles available');
        }
    } catch (error) {
        console.error('Failed to load articles:', error);
        showError('Failed to load articles. Please try again later.');
    } finally {
        hideLoading();
    }
}

// Load articles from all categories
async function loadArticles() {
    const responses = await Promise.all(
        CATEGORIES.map(async category => {
            try {
                const response = await fetch(`data/${category}.json`);
                if (!response.ok) throw new Error(`${category} load failed`);
                return await response.json();
            } catch (error) {
                console.error(`Error loading ${category}:`, error);
                return [];
            }
        })
    );
    return responses.flat().sort((a, b) => new Date(b.date) - new Date(a.date));
}

// Render articles to the page
function renderArticles(articles) {
    const container = document.getElementById('articles-container');
    if (!container) return;
    
    container.innerHTML = articles.map(article => `
        <article class="article-card" data-category="${article.category}">
            <img src="${article.image}" alt="${article.title}">
            <div class="article-content">
                <span class="category-badge">${formatCategory(article.category)}</span>
                <h3><a href="article.html?category=${article.category}&id=${article.id}">${article.title}</a></h3>
                <p class="excerpt">${article.excerpt}</p>
                <div class="article-meta">
                    <span>${formatDate(article.date)}</span>
                    <span>By ${article.author || 'Staff'}</span>
                </div>
            </div>
        </article>
    `).join('');
}

// Set up category filters
function setupFilters() {
    document.querySelectorAll('.category-filter').forEach(btn => {
        btn.addEventListener('click', () => {
            filterArticles(btn.dataset.category);
        });
    });
}

// Filter articles by category
function filterArticles(category) {
    document.querySelectorAll('.article-card').forEach(card => {
        card.style.display = (category === 'all' || card.dataset.category === category) 
            ? 'block' 
            : 'none';
    });
}

// Set up search functionality
function setupSearch() {
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase();
            document.querySelectorAll('.article-card').forEach(card => {
                const text = card.textContent.toLowerCase();
                card.style.display = text.includes(query) ? 'block' : 'none';
            });
        });
    }
}

// Helper functions
function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

function formatCategory(category) {
    return category.charAt(0).toUpperCase() + category.slice(1);
}

function showLoading() {
    const loader = document.getElementById('loading-indicator');
    if (loader) loader.style.display = 'block';
}

function hideLoading() {
    const loader = document.getElementById('loading-indicator');
    if (loader) loader.style.display = 'none';
}

function showError(message) {
    const errorDiv = document.getElementById('error-message');
    if (errorDiv) {
        errorDiv.innerHTML = `
            <div class="error-content">
                <i class="fas fa-exclamation-circle"></i>
                <span>${message}</span>
            </div>
            <button onclick="loadAndDisplayArticles()">Retry</button>
        `;
        errorDiv.style.display = 'block';
    }
}
