module.exports = {
    host: 'localhost', // or your Hostinger database host
    user: 'your_username', // replace with your database username
    password: 'your_password', // replace with your database password
    database: 'website_db' // name of the database
};
