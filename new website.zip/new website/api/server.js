const express = require('express');
const mysql = require('mysql');
const viewCountRouter = require('./view-count');
const dbConfig = require('../db_config');

const connection = mysql.createConnection({
    host: dbConfig.host,
    user: dbConfig.user,
    password: dbConfig.password,
    database: dbConfig.database
});

connection.connect((err) => {
    if (err) {
        console.error('Error connecting to the database:', err);
        return;
    }
    console.log('Connected to the MySQL database.');
});
const app = express();

// Middleware
app.use(express.json());
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});

// Routes
app.use('/api/view-count', viewCountRouter);

// Start server
const PORT = 8000;
app.listen(PORT, () => {
    console.log(`View count API running on port ${PORT}`);
});
