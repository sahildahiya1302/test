const express = require('express');
const express = require('express');
const router = express.Router();
const mysql = require('mysql');
const dbConfig = require('../db_config');

const connection = mysql.createConnection({
    host: dbConfig.host,
    user: dbConfig.user,
    password: dbConfig.password,
    database: dbConfig.database
});

connection.connect((err) => {
    if (err) {
        console.error('Error connecting to the database:', err);
        return;
    }
    console.log('Connected to the MySQL database.');
});

// Simple in-memory store (replace with database in production)
const viewCounts = new Map();

router.post('/', (req, res) => {
    try {
        const { category, id } = req.query;
        if (!category || !id) {
            return res.status(400).json({ error: 'Missing category or id' });
        }

        const key = `${category}-${id}`;
        const currentCount = (viewCounts.get(key) || 0) + 1;
        viewCounts.set(key, currentCount);

        res.json({ 
            success: true,
            views: currentCount,
            message: 'View count updated'
        });
    } catch (error) {
        console.error('Error updating view count:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

module.exports = router;
