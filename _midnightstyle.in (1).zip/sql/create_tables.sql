CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    wallet_balance DECIMAL(10, 2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    status ENUM('active', 'suspended', 'banned') DEFAULT 'active'
);

CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM('deposit', 'withdrawal', 'game_entry', 'winning'),
    amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'completed', 'failed'),
    payment_gateway VARCHAR(50),
    transaction_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS game_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    game_type ENUM('ludo', 'aviator'),
    entry_fee DECIMAL(10, 2),
    total_players INT,
    bot_count INT DEFAULT 0,
    status ENUM('waiting', 'active', 'completed'),
    winner_id INT,
    prize_pool DECIMAL(10, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS games (
    id INT AUTO_INCREMENT PRIMARY KEY,
    game_type ENUM('ludo', 'aviator'),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    winner INT,
    details TEXT
);

CREATE TABLE IF NOT EXISTS admin_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    current_payment_gateway ENUM('payu', 'razorpay', 'stripe') DEFAULT 'payu',
    payu_keys TEXT,
    razorpay_keys TEXT,
    stripe_keys TEXT,
    ludo_bot_probability DECIMAL(5, 2) DEFAULT 0.40,
    aviator_parameters TEXT
);
