<?php
session_start();

// Set session timeout duration (30 minutes)
$timeout_duration = 1800; // 30 minutes

// Check if the user is authenticated
function requireAuth() {
    global $timeout_duration;

    // Check if the user is logged in
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit();
    }

    // Check for session timeout
    if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
        // Last request was more than 30 minutes ago
        session_unset(); // Unset session variables
        session_destroy(); // Destroy the session
        header("Location: login.php");
        exit();
    }

    $_SESSION['LAST_ACTIVITY'] = time(); // Update last activity time
}
?>
