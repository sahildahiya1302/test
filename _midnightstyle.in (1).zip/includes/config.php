<?php
// Database credentials
define('DB_HOST', 'localhost'); // Hostname
define('DB_USER', 'u185229455_gamingdata'); // MySQL username
define('DB_PASS', 'Sahil@hostinger#ssh2025'); // MySQL password
define('DB_NAME', 'u185229455_sahil'); // Database name

// Session timeout settings
define('SESSION_TIMEOUT', 3600); // 1 hour

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
