<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is authenticated as admin
requireAuth(); // You may want to implement a specific admin check here

// Fetch all users from the database
$pdo = getDBConnection();
$stmt = $pdo->query("SELECT id, username, wallet_balance, created_at FROM users");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management</title>
    <link rel="stylesheet" href="../assets/css/style.css"> <!-- Link to your CSS file -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Handle delete user action
            $('.delete-user').on('click', function(e) {
                e.preventDefault();
                const userId = $(this).data('id');
                if (confirm('Are you sure you want to delete this user?')) {
                    $.ajax({
                        url: 'delete_user.php', // Endpoint to delete user
                        method: 'POST',
                        data: { id: userId },
                        success: function(response) {
                            if (response.success) {
                                alert('User deleted successfully!');
                                location.reload(); // Reload the page to reflect changes
                            } else {
                                alert('Error deleting user: ' + response.message);
                            }
                        },
                        error: function() {
                            alert('Error processing request. Please try again.');
                        }
                    });
                }
            });
        });
    </script>
</head>
<body>
    <h1>User Management</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Wallet Balance</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['id']); ?></td>
                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                    <td>$<?php echo htmlspecialchars($user['wallet_balance']); ?></td>
                    <td><?php echo htmlspecialchars($user['created_at']); ?></td>
                    <td>
                        <a href="edit_user.php?id=<?php echo $user['id']; ?>">Edit</a>
                        <a href="#" class="delete-user" data-id="<?php echo $user['id']; ?>">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
?>
