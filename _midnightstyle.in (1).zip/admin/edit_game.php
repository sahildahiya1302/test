<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is authenticated as admin
requireAuth(); // You may want to implement a specific admin check here

if (!isset($_GET['id'])) {
    header("Location: games.php");
    exit();
}

$game_id = $_GET['id'];

// Fetch game details from the database
$pdo = getDBConnection();
$stmt = $pdo->prepare("SELECT game_type, status FROM games WHERE id = :id");
$stmt->execute(['id' => $game_id]);
$game = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_game_type = $_POST['game_type'];
    $new_status = $_POST['status'];

    // Update game details in the database
    $stmt = $pdo->prepare("UPDATE games SET game_type = :game_type, status = :status WHERE id = :id");
    $stmt->execute(['game_type' => $new_game_type, 'status' => $new_status, 'id' => $game_id]);

    // Redirect back to games page after successful update
    header("Location: games.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Game</title>
    <link rel="stylesheet" href="../assets/css/style.css"> <!-- Link to your CSS file -->
</head>
<body>
    <h1>Edit Game</h1>
    <form method="POST" action="">
        <label for="game_type">Game Type:</label>
        <input type="text" name="game_type" value="<?php echo htmlspecialchars($game['game_type']); ?>" required>
        
        <label for="status">Status:</label>
        <select name="status" required>
            <option value="active" <?php echo ($game['status'] === 'active') ? 'selected' : ''; ?>>Active</option>
            <option value="inactive" <?php echo ($game['status'] === 'inactive') ? 'selected' : ''; ?>>Inactive</option>
        </select>
        
        <button type="submit">Update Game</button>
    </form>
    <a href="games.php">Back to Manage Games</a>
</body>
</html>
<?php
// Close the database connection
$pdo = null;
?>
