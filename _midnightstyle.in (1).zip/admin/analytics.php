<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is authenticated as admin
requireAuth(); // You may want to implement a specific admin check here

// Fetch analytics data (example query)
$pdo = getDBConnection();
$stmt = $pdo->query("SELECT COUNT(*) AS total_users FROM users");
$total_users = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) AS total_games FROM games");
$total_games = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT SUM(wallet_balance) AS total_wallet_balance FROM users");
$total_wallet_balance = $stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics</title>
    <link rel="stylesheet" href="../assets/css/style.css"> <!-- Link to your CSS file -->
</head>
<body>
    <h1>Analytics Dashboard</h1>
    <h2>Overview</h2>
    <p>Total Users: <?php echo htmlspecialchars($total_users); ?></p>
    <p>Total Games: <?php echo htmlspecialchars($total_games); ?></p>
    <p>Total Wallet Balance: $<?php echo htmlspecialchars($total_wallet_balance); ?></p>
    
    <a href="index.php">Back to Admin Dashboard</a>
</body>
</html>
<?php
// Close the database connection
$pdo = null;
?>
