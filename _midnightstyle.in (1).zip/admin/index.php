<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is authenticated as admin
requireAuth(); // You may want to implement a specific admin check here

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../assets/css/style.css"> <!-- Link to your CSS file -->
</head>
<body>
    <div class="admin-container">
        <nav class="admin-nav">
            <h2>Admin Dashboard</h2>
            <ul>
                <li><a href="users.php">User Management</a></li>
                <li><a href="settings.php">Settings</a></li>
                <li><a href="analytics.php">Analytics</a></li>
                <li><a href="games.php">Manage Games</a></li>
                <li><a href="../public_html/logout.php">Logout</a></li>
            </ul>
        </nav>
        <main>
            <h2>Overview</h2>
            <p>Welcome to the admin dashboard. Use the navigation links to manage the application.</p>
            <h3>Key Metrics</h3>
            <ul>
                <li>Total Users: <span id="total-users">0</span></li>
                <li>Total Revenue: $<span id="total-revenue">0.00</span></li>
                <li>Active Games: <span id="active-games">0</span></li>
            </ul>
        </main>
    </div>
</body>
</html>
<?php
// Close the database connection
$pdo = null;
?>
