<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is authenticated as admin
requireAuth(); // You may want to implement a specific admin check here

if (!isset($_GET['id'])) {
    header("Location: games.php");
    exit();
}

$game_id = $_GET['id'];

// Delete game from the database
$pdo = getDBConnection();
$stmt = $pdo->prepare("DELETE FROM games WHERE id = :id");
$stmt->execute(['id' => $game_id]);

// Redirect back to games page after successful deletion
header("Location: games.php");
exit();
?>
