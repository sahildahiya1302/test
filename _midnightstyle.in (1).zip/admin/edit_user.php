<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is authenticated as admin
requireAuth(); // You may want to implement a specific admin check here

if (!isset($_GET['id'])) {
    header("Location: users.php");
    exit();
}

$user_id = $_GET['id'];

// Fetch user details from the database
$pdo = getDBConnection();
$stmt = $pdo->prepare("SELECT username, wallet_balance FROM users WHERE id = :id");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_username = $_POST['username'];
    $new_wallet_balance = $_POST['wallet_balance'];

    // Update user details in the database
    $stmt = $pdo->prepare("UPDATE users SET username = :username, wallet_balance = :wallet_balance WHERE id = :id");
    $stmt->execute(['username' => $new_username, 'wallet_balance' => $new_wallet_balance, 'id' => $user_id]);

    // Redirect back to users page after successful update
    header("Location: users.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link rel="stylesheet" href="../assets/css/style.css"> <!-- Link to your CSS file -->
</head>
<body>
    <h1>Edit User</h1>
    <form method="POST" action="">
        <label for="username">Username:</label>
        <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
        
        <label for="wallet_balance">Wallet Balance:</label>
        <input type="number" name="wallet_balance" value="<?php echo htmlspecialchars($user['wallet_balance']); ?>" required>
        
        <button type="submit">Update User</button>
    </form>
    <a href="users.php">Back to User Management</a>
</body>
</html>
<?php
// Close the database connection
$pdo = null;
?>
