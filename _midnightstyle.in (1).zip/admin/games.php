<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is authenticated as admin
requireAuth(); // You may want to implement a specific admin check here

// Fetch all games from the database
$pdo = getDBConnection();
$stmt = $pdo->query("SELECT id, game_type, status FROM games");
$games = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Games</title>
    <link rel="stylesheet" href="../assets/css/style.css"> <!-- Link to your CSS file -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Handle delete game action
            $('.delete-game').on('click', function(e) {
                e.preventDefault();
                const gameId = $(this).data('id');
                if (confirm('Are you sure you want to delete this game?')) {
                    $.ajax({
                        url: 'delete_game.php', // Endpoint to delete game
                        method: 'POST',
                        data: { id: gameId },
                        success: function(response) {
                            if (response.success) {
                                alert('Game deleted successfully!');
                                location.reload(); // Reload the page to reflect changes
                            } else {
                                alert('Error deleting game: ' + response.message);
                            }
                        },
                        error: function() {
                            alert('Error processing request. Please try again.');
                        }
                    });
                }
            });
        });
    </script>
</head>
<body>
    <h1>Manage Games</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Game Type</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($games as $game): ?>
                <tr>
                    <td><?php echo htmlspecialchars($game['id']); ?></td>
                    <td><?php echo htmlspecialchars($game['game_type']); ?></td>
                    <td><?php echo htmlspecialchars($game['status']); ?></td>
                    <td>
                        <a href="edit_game.php?id=<?php echo $game['id']; ?>">Edit</a>
                        <a href="#" class="delete-game" data-id="<?php echo $game['id']; ?>">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <a href="index.php">Back to Admin Dashboard</a>
</body>
</html>
<?php
// Close the database connection
$pdo = null;
?>
