<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is authenticated as admin
requireAuth(); // You may want to implement a specific admin check here

// Fetch current payment gateway settings
$pdo = getDBConnection();
$stmt = $pdo->query("SELECT current_payment_gateway, payu_keys, razorpay_keys, stripe_keys FROM admin_settings LIMIT 1");
$settings = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_gateway = $_POST['current_payment_gateway'];
    $payu_keys = $_POST['payu_keys'];
    $razorpay_keys = $_POST['razorpay_keys'];
    $stripe_keys = $_POST['stripe_keys'];

    // Update payment gateway settings in the database
    $stmt = $pdo->prepare("UPDATE admin_settings SET current_payment_gateway = :current_gateway, payu_keys = :payu_keys, razorpay_keys = :razorpay_keys, stripe_keys = :stripe_keys WHERE id = 1");
    $stmt->execute([
        'current_gateway' => $current_gateway,
        'payu_keys' => $payu_keys,
        'razorpay_keys' => $razorpay_keys,
        'stripe_keys' => $stripe_keys
    ]);

    // Refresh settings
    $settings = [
        'current_payment_gateway' => $current_gateway,
        'payu_keys' => $payu_keys,
        'razorpay_keys' => $razorpay_keys,
        'stripe_keys' => $stripe_keys
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
    <link rel="stylesheet" href="../assets/css/style.css"> <!-- Link to your CSS file -->
</head>
<body>
    <h1>Payment Gateway Settings</h1>
    <form method="POST" action="">
        <label for="current_payment_gateway">Current Payment Gateway:</label>
        <select name="current_payment_gateway" required>
            <option value="payu" <?php echo ($settings['current_payment_gateway'] === 'payu') ? 'selected' : ''; ?>>PayU</option>
            <option value="razorpay" <?php echo ($settings['current_payment_gateway'] === 'razorpay') ? 'selected' : ''; ?>>Razorpay</option>
            <option value="stripe" <?php echo ($settings['current_payment_gateway'] === 'stripe') ? 'selected' : ''; ?>>Stripe</option>
        </select>

        <label for="payu_keys">PayU Keys:</label>
        <input type="text" name="payu_keys" value="<?php echo htmlspecialchars($settings['payu_keys']); ?>" required>

        <label for="razorpay_keys">Razorpay Keys:</label>
        <input type="text" name="razorpay_keys" value="<?php echo htmlspecialchars($settings['razorpay_keys']); ?>" required>

        <label for="stripe_keys">Stripe Keys:</label>
        <input type="text" name="stripe_keys" value="<?php echo htmlspecialchars($settings['stripe_keys']); ?>" required>

        <button type="submit">Update Settings</button>
    </form>
    <a href="index.php">Back to Admin Dashboard</a>
</body>
</html>
<?php
// Close the database connection
$pdo = null;
?>
