<?php
define('PAYU_KEY', 'u185229455_payu_key'); // Replace with actual key
define('PAYU_SALT', 'u185229455_payu_salt'); // Replace with actual salt
define('RAZORPAY_KEY', 'u185229455_razorpay_key'); // Replace with actual key
define('RAZORPAY_SECRET', 'u185229455_razorpay_secret'); // Replace with actual secret
define('STRIPE_KEY', 'u185229455_stripe_key'); // Replace with actual key
define('STRIPE_SECRET', 'u185229455_stripe_secret'); // Replace with actual secret

// Payment gateway settings
define('DEFAULT_PAYMENT_GATEWAY', 'payu'); // Default payment gateway
?>
