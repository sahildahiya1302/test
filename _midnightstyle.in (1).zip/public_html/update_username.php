<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is authenticated
requireAuth();

// Fetch user ID
$user_id = $_SESSION['user_id'];
$pdo = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_username = $_POST['username'];

    // Validate new username
    if (!empty($new_username)) {
        // Check if the username is unique
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = :username AND id != :id");
        $stmt->execute(['username' => $new_username, 'id' => $user_id]);
        $count = $stmt->fetchColumn();

        if ($count == 0) {
            // Update username in the database
            $stmt = $pdo->prepare("UPDATE users SET username = :username WHERE id = :id");
            $stmt->execute(['username' => $new_username, 'id' => $user_id]);

            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Username already taken.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Username cannot be empty.']);
    }
}
?>
