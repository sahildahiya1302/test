<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is authenticated
requireAuth();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $game = $_POST['game'];
    $entry_fee = $_POST['entry_fee'];

    // Here you would implement the logic to create a game room
    // For now, we will just display the selected game and entry fee
} else {
    // Redirect back to the game lobby if accessed directly
    header("Location: game_lobby.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Game Room</title>
    <link rel="stylesheet" href="assets/css/style.css"> <!-- Link to your CSS file -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        let countdown;
        $(document).ready(function() {
            // Start countdown timer
            countdown = 30; // 30 seconds
            const timerDisplay = $('#timer');
            const countdownInterval = setInterval(function() {
                if (countdown <= 0) {
                    clearInterval(countdownInterval);
                    alert('Time is up!'); // Handle timeout logic here
                } else {
                    timerDisplay.text(countdown + ' seconds remaining');
                    countdown--;
                }
            }, 1000);
        });
    </script>
</head>
<body>
    <h1>Game Room</h1>
    <h2>Game: <?php echo htmlspecialchars($game); ?></h2>
    <p>Entry Fee: $<?php echo htmlspecialchars($entry_fee); ?></p>
    <p id="timer">30 seconds remaining</p>
    <p>Waiting for players to join...</p>
    
    <div id="player-list">
        <h3>Joined Players:</h3>
        <ul>
            <!-- Player information will be dynamically populated here -->
        </ul>
    </div>
    
    <a href="game_lobby.php">Back to Game Lobby</a>
</body>
</html>
<?php
// Close the database connection
$pdo = null;
?>
