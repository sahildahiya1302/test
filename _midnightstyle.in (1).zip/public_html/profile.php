<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is authenticated
requireAuth();

// Fetch user details from the database
$user_id = $_SESSION['user_id'];
$pdo = getDBConnection();
$stmt = $pdo->prepare("SELECT username, wallet_balance FROM users WHERE id = :id");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_username = $_POST['username'];

    // Update user details in the database
    $stmt = $pdo->prepare("UPDATE users SET username = :username WHERE id = :id");
    $stmt->execute(['username' => $new_username, 'id' => $user_id]);

    // Refresh user details
    $user['username'] = $new_username;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="assets/css/style.css"> <!-- Link to your CSS file -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Function to update username dynamically
            $('#update-username-form').on('submit', function(e) {
                e.preventDefault();
                var newUsername = $('#username').val();
                $.ajax({
                    url: 'update_username.php', // Endpoint to update username
                    method: 'POST',
                    data: { username: newUsername },
                    success: function(response) {
                        if (response.success) {
                            alert('Username updated successfully!');
                            location.reload(); // Reload to fetch new user data
                        } else {
                            alert('Error updating username: ' + response.message);
                        }
                    },
                    error: function() {
                        alert('Error updating username. Please try again.');
                    }
                });
            });
        });
    </script>
</head>
<body>
    <h1>User Profile</h1>
    <form id="update-username-form" method="POST" action="">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
        <button type="submit">Update</button>
    </form>
    <p>Wallet Balance: $<?php echo htmlspecialchars($user['wallet_balance']); ?></p>
    <a href="wallet.php">Manage Wallet</a>
    <a href="index.php">Back to Home</a>
    <h2>Update Profile Picture</h2>
    <form method="POST" action="upload_profile_picture.php" enctype="multipart/form-data">
        <label for="profile_picture">Choose a profile picture:</label>
        <input type="file" name="profile_picture" accept="image/*" required>
        <button type="submit">Upload</button>
    </form>
</body>
</html>
<?php
// Close the database connection
$pdo = null;
?>
