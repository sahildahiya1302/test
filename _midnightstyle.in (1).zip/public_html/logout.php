<?php
require_once '../includes/auth.php';

// Call the logout function to destroy the session
logout();
?>
