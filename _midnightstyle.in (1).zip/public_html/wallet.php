<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is authenticated
requireAuth();

// Fetch user details from the database
$user_id = $_SESSION['user_id'];
$pdo = getDBConnection();
$stmt = $pdo->prepare("SELECT wallet_balance FROM users WHERE id = :id");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];
    $amount = $_POST['amount'];

    if ($action === 'deposit') {
        // Update wallet balance for deposit
        $stmt = $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance + :amount WHERE id = :id");
        $stmt->execute(['amount' => $amount, 'id' => $user_id]);
    } elseif ($action === 'withdraw') {
        // Update wallet balance for withdrawal
        $stmt = $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance - :amount WHERE id = :id");
        $stmt->execute(['amount' => $amount, 'id' => $user_id]);
    }
    
    // Refresh user details
    $stmt = $pdo->prepare("SELECT wallet_balance FROM users WHERE id = :id");
    $stmt->execute(['id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wallet Management</title>
    <link rel="stylesheet" href="assets/css/style.css"> <!-- Link to your CSS file -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Function to update wallet balance dynamically
            function updateWalletBalance() {
                $.ajax({
                    url: 'get_wallet_balance.php', // Endpoint to fetch wallet balance
                    method: 'GET',
                    success: function(data) {
                        $('#current-balance').text('$' + data.balance);
                    },
                    error: function() {
                        $('#current-balance').text('Error loading balance');
                    }
                });
            }

            // Call the function to update wallet balance on page load
            updateWalletBalance();

            // Handle deposit and withdrawal forms
            $('form').on('submit', function(e) {
                e.preventDefault();
                var action = $(this).find('input[name="action"]').val();
                var amount = $(this).find('input[name="amount"]').val();

                if (action === 'withdraw' && amount > parseFloat($('#current-balance').text().replace('$', ''))) {
                    alert('Withdrawal amount exceeds available balance.');
                    return;
                }

                $.ajax({
                    url: 'update_wallet.php', // Endpoint to handle wallet updates
                    method: 'POST',
                    data: { action: action, amount: amount },
                    success: function(response) {
                        if (response.success) {
                            alert('Transaction successful!');
                            updateWalletBalance(); // Refresh wallet balance
                        } else {
                            alert('Error: ' + response.message);
                        }
                    },
                    error: function() {
                        alert('Error processing transaction. Please try again.');
                    }
                });
            });
        });
    </script>
</head>
<body>
    <h1>Wallet Management</h1>
    <p>Current Wallet Balance: <span id="current-balance">$<?php echo htmlspecialchars($user['wallet_balance']); ?></span></p>
    
    <h2>Deposit</h2>
    <form method="POST" action="">
        <input type="hidden" name="action" value="deposit">
        <label for="amount">Amount:</label>
        <input type="number" name="amount" required>
        <button type="submit">Deposit</button>
    </form>

    <h2>Withdraw</h2>
    <form method="POST" action="">
        <input type="hidden" name="action" value="withdraw">
        <label for="amount">Amount:</label>
        <input type="number" name="amount" required>
        <button type="submit">Withdraw</button>
    </form>

    <h2>Transaction History</h2>
    <table>
        <thead>
            <tr>
                <th>Transaction ID</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Fetch transaction history from the database
            $stmt = $pdo->prepare("SELECT * FROM transactions WHERE user_id = :user_id ORDER BY created_at DESC");
            $stmt->execute(['user_id' => $user_id]);
            $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($transactions as $transaction):
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($transaction['transaction_id']); ?></td>
                    <td><?php echo htmlspecialchars($transaction['type']); ?></td>
                    <td>$<?php echo htmlspecialchars($transaction['amount']); ?></td>
                    <td><?php echo htmlspecialchars($transaction['status']); ?></td>
                    <td><?php echo htmlspecialchars($transaction['created_at']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <a href="profile.php">Back to Profile</a>
    <a href="index.php">Back to Home</a>
</body>
</html>
<?php
// Close the database connection
$pdo = null;
?>
