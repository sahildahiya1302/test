<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is authenticated
requireAuth();

// Fetch user ID
$user_id = $_SESSION['user_id'];
$pdo = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];
    $amount = $_POST['amount'];

    if ($action === 'deposit') {
        // Validate deposit amount
        if ($amount > 0) {
            // Update wallet balance for deposit
            $stmt = $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance + :amount WHERE id = :id");
            $stmt->execute(['amount' => $amount, 'id' => $user_id]);

            // Insert transaction record
            $stmt = $pdo->prepare("INSERT INTO transactions (user_id, type, amount, status) VALUES (:user_id, 'deposit', :amount, 'completed')");
            $stmt->execute(['user_id' => $user_id, 'amount' => $amount]);

            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid deposit amount.']);
        }
    } elseif ($action === 'withdraw') {
        // Fetch current wallet balance
        $stmt = $pdo->prepare("SELECT wallet_balance FROM users WHERE id = :id");
        $stmt->execute(['id' => $user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Validate withdrawal amount
        if ($amount > 0 && $amount <= $user['wallet_balance']) {
            // Update wallet balance for withdrawal
            $stmt = $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance - :amount WHERE id = :id");
            $stmt->execute(['amount' => $amount, 'id' => $user_id]);

            // Insert transaction record
            $stmt = $pdo->prepare("INSERT INTO transactions (user_id, type, amount, status) VALUES (:user_id, 'withdrawal', :amount, 'completed')");
            $stmt->execute(['user_id' => $user_id, 'amount' => $amount]);

            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid withdrawal amount or insufficient balance.']);
        }
    }
}
?>
