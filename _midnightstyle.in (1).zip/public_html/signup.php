<?php
require_once '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $wallet_balance = 0; // Default wallet balance

    // Hash the password
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // Insert user into the database
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, wallet_balance) VALUES (:username, :password_hash, :wallet_balance)");
    $stmt->execute([':username' => $username, ':password_hash' => $password_hash, ':wallet_balance' => $wallet_balance]);

    // Redirect to login page after successful signup
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="assets/css/style.css"> </head>
<body>
    <h1>Sign Up</h1>
    <form method="POST" action="" novalidate>
        <label for="username">Username:</label>
        <input type="text" name="username" required aria-required="true" placeholder="Enter your username">
        <label for="password">Password:</label>
        <input type="password" name="password" required aria-required="true" placeholder="Enter your password">
        <button type="submit">Sign Up</button>
    </form>
    <p>Already have an account? <a href="login.php">Login</a></p>
</body>
</html>
<?php
// Close the database connection
$pdo = null;
?>