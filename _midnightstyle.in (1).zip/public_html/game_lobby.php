<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is authenticated
requireAuth();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Game Lobby</title>
    <link rel="stylesheet" href="assets/css/style.css"> <!-- Link to your CSS file -->
</head>
<body>
    <h1>Game Lobby</h1>
    <h2>Select a Game</h2>
    <div class="game-container">
        <div class="game-card">
            <h3>Ludo</h3>
            <p>Select Entry Fee:</p>
            <form method="POST" action="game_room.php">
                <input type="hidden" name="game" value="ludo">
                <select name="entry_fee" required>
                    <option value="10">10</option>
                    <option value="20">20</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                    <option value="500">500</option>
                    <option value="1000">1000</option>
                </select>
                <button type="submit">Enter Game</button>
            </form>
        </div>
        <div class="game-card">
            <h3>Aviator</h3>
            <p>Select Entry Fee:</p>
            <form method="POST" action="game_room.php">
                <input type="hidden" name="game" value="aviator">
                <select name="entry_fee" required>
                    <option value="10">10</option>
                    <option value="20">20</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                    <option value="500">500</option>
                    <option value="1000">1000</option>
                </select>
                <button type="submit">Enter Game</button>
            </form>
        </div>
    </div>
    <a href="index.php">Back to Home</a>
</body>
</html>
<?php
// Close the database connection
$pdo = null;
?>
