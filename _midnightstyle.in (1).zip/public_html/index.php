<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is authenticated
requireAuth();

// Fetch user details from the database (example query)
$user_id = $_SESSION['user_id'];
$pdo = getDBConnection();
$stmt = $pdo->prepare("SELECT username, wallet_balance FROM users WHERE id = :id");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gaming App</title>
    <link rel="stylesheet" href="assets/css/style.css"> <!-- Link to your CSS file -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Function to update wallet balance dynamically
            function updateWalletBalance() {
                $.ajax({
                    url: 'get_wallet_balance.php', // Endpoint to fetch wallet balance
                    method: 'GET',
                    success: function(data) {
                        $('#wallet-balance').text('$' + data.balance);
                    },
                    error: function() {
                        $('#wallet-balance').text('Error loading balance');
                    }
                });
            }

            // Call the function to update wallet balance on page load
            updateWalletBalance();
        });
    </script>
</head>
<body>
    <header>
        <div class="header-container">
            <h1>Welcome, <?php echo htmlspecialchars($user['username']); ?></h1>
            <p id="wallet-balance">Wallet Balance: $<?php echo htmlspecialchars($user['wallet_balance']); ?></p>
            <div class="profile-menu">
                <img src="assets/images/profile_icon.png" alt="Profile" class="profile-icon">
                <div class="dropdown">
                    <a href="profile.php">Profile</a>
                    <a href="wallet.php">Wallet</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </header>
    <main>
        <h2>Available Games</h2>
        <!-- Game listing will be dynamically generated here -->
    </main>
</body>
</html>
<?php
// Close the database connection
$pdo = null;
?>
