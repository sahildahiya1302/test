<?php
// Entry point for the application
require 'config.php'; // Include database configuration

session_start(); // Start the session

// Check if the user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: frontend/index.html");
    exit();
}

// Redirect to login page if not logged in
header("Location: frontend/login.html");
exit();
?>
