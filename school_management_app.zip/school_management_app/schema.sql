CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    user_type ENUM('admin', 'teacher', 'student') NOT NULL,
    role_id INT,
    FOREIGN KEY (role_id) REFERENCES roles(role_id)
);

CREATE TABLE roles (
    role_id INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    srn_number VARCHAR(20) NOT NULL UNIQUE,
    admission_number VARCHAR(20) NOT NULL UNIQUE,
    date_of_admission DATE NOT NULL,
    class VARCHAR(20) NOT NULL,
    section VARCHAR(20) NOT NULL
);

CREATE TABLE fees (
    fee_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    due_date DATE NOT NULL,
    FOREIGN KEY (student_id) REFERENCES students(id)
);

CREATE TABLE exams (
    exam_id INT AUTO_INCREMENT PRIMARY KEY,
    exam_name VARCHAR(50) NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    class VARCHAR(20) NOT NULL
);

CREATE TABLE health_records (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    health_issue TEXT,
    vaccination_status VARCHAR(50),
    date DATE NOT NULL,
    FOREIGN KEY (student_id) REFERENCES students(id)
);

CREATE TABLE inventory (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    item_name VARCHAR(50) NOT NULL,
    quantity INT NOT NULL,
    description TEXT
);

CREATE TABLE results (
    result_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    exam_name VARCHAR(50) NOT NULL,
    subject VARCHAR(50) NOT NULL,
    marks DECIMAL(5, 2) NOT NULL,
    FOREIGN KEY (student_id) REFERENCES students(id)
);
