// JavaScript for interactivity
document.addEventListener('DOMContentLoaded', function() {
    fetch('backend/get_students.php')
        .then(response => response.json())
        .then(data => {
            const tbody = document.querySelector('tbody');
            data.forEach(student => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${student.first_name}</td>
                    <td>${student.last_name}</td>
                    <td>${student.srn_number}</td>
                    <td>${student.admission_number}</td>
                    <td>${student.date_of_admission}</td>
                    <td>${student.class}</td>
                    <td>${student.section}</td>
                    <td>
                        <a href="edit_student.html?id=${student.id}">Edit</a>
                        <a href="delete_student.php?id=${student.id}">Delete</a>
                    </td>
                `;
                tbody.appendChild(row);
            });
        })
        .catch(error => console.error('Error fetching students:', error));
});
