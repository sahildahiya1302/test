<?php
session_start();
require 'config.php';

// Fetch all students from the database
$stmt = $conn->prepare("SELECT * FROM students");
$stmt->execute();
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Return the student data as JSON
header('Content-Type: application/json');
echo json_encode($students);
?>
