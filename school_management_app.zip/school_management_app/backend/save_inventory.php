<?php
// Include database configuration
require 'config.php';

// Function to save inventory items
function saveInventory($conn) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $item_name = $_POST['item_name'];
        $quantity = $_POST['quantity'];
        $description = $_POST['description'];

        // Insert inventory item into the database
        $stmt = $conn->prepare("INSERT INTO inventory (item_name, quantity, description) VALUES (:item_name, :quantity, :description)");
        $stmt->bindParam(':item_name', $item_name);
        $stmt->bindParam(':quantity', $quantity);
        $stmt->bindParam(':description', $description);
        
        if ($stmt->execute()) {
            echo "Inventory item saved successfully.";
        } else {
            echo "Error saving inventory item.";
        }
    }
}

// Call the function to save inventory items
saveInventory($conn);
?>
