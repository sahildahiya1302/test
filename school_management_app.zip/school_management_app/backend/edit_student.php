<?php
session_start();
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = $_POST['student_id'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $srn_number = $_POST['srn_number'];
    $admission_number = $_POST['admission_number'];
    $date_of_admission = $_POST['date_of_admission'];
    $class = $_POST['class'];
    $section = $_POST['section'];

    // Prepare and execute the SQL statement
    $stmt = $conn->prepare("UPDATE students SET first_name = :first_name, last_name = :last_name, srn_number = :srn_number, admission_number = :admission_number, date_of_admission = :date_of_admission, class = :class, section = :section WHERE id = :student_id");
    $stmt->bindParam(':first_name', $first_name);
    $stmt->bindParam(':last_name', $last_name);
    $stmt->bindParam(':srn_number', $srn_number);
    $stmt->bindParam(':admission_number', $admission_number);
    $stmt->bindParam(':date_of_admission', $date_of_admission);
    $stmt->bindParam(':class', $class);
    $stmt->bindParam(':section', $section);
    $stmt->bindParam(':student_id', $student_id);

    if ($stmt->execute()) {
        echo "Student updated successfully.";
    } else {
        echo "Error updating student.";
    }
}
?>
