<?php
// Include database configuration
require 'config.php';

// Function to save exam details
function saveExam($conn) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $exam_name = $_POST['exam_name'];
        $date = $_POST['date'];
        $time = $_POST['time'];
        $class = $_POST['class'];

        // Insert exam record into the database
        $stmt = $conn->prepare("INSERT INTO exams (exam_name, date, time, class) VALUES (:exam_name, :date, :time, :class)");
        $stmt->bindParam(':exam_name', $exam_name);
        $stmt->bindParam(':date', $date);
        $stmt->bindParam(':time', $time);
        $stmt->bindParam(':class', $class);
        
        if ($stmt->execute()) {
            echo "Exam saved successfully.";
        } else {
            echo "Error saving exam.";
        }
    }
}

// Call the function to save exam details
saveExam($conn);
?>
