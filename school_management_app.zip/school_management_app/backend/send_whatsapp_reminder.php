<?php
// Include database configuration
require 'config.php';

// Function to send WhatsApp reminders
function sendWhatsAppReminder($conn) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $message = $_POST['message'];
        $recipient = $_POST['recipient']; // This should be the phone number of the recipient

        // Here you would integrate with the WhatsApp API
        // For example, using Twilio or another service
        // This is a placeholder for the actual API call
        $api_url = "https://api.whatsapp.com/send?phone=$recipient&text=" . urlencode($message);

        // Simulate sending the message
        $response = file_get_contents($api_url);

        if ($response) {
            echo "WhatsApp reminder sent successfully.";
        } else {
            echo "Error sending WhatsApp reminder.";
        }
    }
}

// Call the function to send WhatsApp reminders
sendWhatsAppReminder($conn);
?>
