<?php
session_start();
require 'config.php';

if (isset($_GET['id'])) {
    $student_id = $_GET['id'];

    // Prepare and execute the SQL statement
    $stmt = $conn->prepare("DELETE FROM students WHERE id = :student_id");
    $stmt->bindParam(':student_id', $student_id);

    if ($stmt->execute()) {
        echo "Student deleted successfully.";
    } else {
        echo "Error deleting student.";
    }
}
?>
