<?php
// Include database configuration
require 'config.php';

// Function to save transportation routes
function saveTransportation($conn) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $route_name = $_POST['route_name'];
        $vehicle_number = $_POST['vehicle_number'];
        $driver_name = $_POST['driver_name'];
        $student_id = $_POST['student_id'];

        // Insert transportation route into the database
        $stmt = $conn->prepare("INSERT INTO transportation (route_name, vehicle_number, driver_name, student_id) VALUES (:route_name, :vehicle_number, :driver_name, :student_id)");
        $stmt->bindParam(':route_name', $route_name);
        $stmt->bindParam(':vehicle_number', $vehicle_number);
        $stmt->bindParam(':driver_name', $driver_name);
        $stmt->bindParam(':student_id', $student_id);
        
        if ($stmt->execute()) {
            echo "Transportation route saved successfully.";
        } else {
            echo "Error saving transportation route.";
        }
    }
}

// Call the function to save transportation routes
saveTransportation($conn);
?>
