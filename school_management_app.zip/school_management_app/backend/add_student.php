<?php
session_start();
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $srn_number = $_POST['srn_number'];
    $admission_number = $_POST['admission_number'];
    $date_of_admission = $_POST['date_of_admission'];
    $class = $_POST['class'];
    $section = $_POST['section'];

    // Prepare and execute the SQL statement
    $stmt = $conn->prepare("INSERT INTO students (first_name, last_name, srn_number, admission_number, date_of_admission, class, section) VALUES (:first_name, :last_name, :srn_number, :admission_number, :date_of_admission, :class, :section)");
    $stmt->bindParam(':first_name', $first_name);
    $stmt->bindParam(':last_name', $last_name);
    $stmt->bindParam(':srn_number', $srn_number);
    $stmt->bindParam(':admission_number', $admission_number);
    $stmt->bindParam(':date_of_admission', $date_of_admission);
    $stmt->bindParam(':class', $class);
    $stmt->bindParam(':section', $section);

    if ($stmt->execute()) {
        echo "Student added successfully.";
    } else {
        echo "Error adding student.";
    }
}
?>
