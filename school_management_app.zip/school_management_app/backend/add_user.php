<?php
session_start();
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $user_type = $_POST['user_type'];

    // Prepare and execute the SQL statement
    $stmt = $conn->prepare("INSERT INTO users (username, password, user_type, role_id) VALUES (:username, :password, :user_type, (SELECT role_id FROM roles WHERE role_name = :user_type))");
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);
    $stmt->bindParam(':user_type', $user_type);

    if ($stmt->execute()) {
        echo "User added successfully.";
    } else {
        echo "Error adding user.";
    }
}
?>
