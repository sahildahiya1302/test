<?php
// Update the users table to include role_id
require 'config.php';

$sql = "ALTER TABLE users ADD role_id INT NOT NULL DEFAULT 0";
$conn->exec($sql);
echo "Table updated successfully.";
?>
