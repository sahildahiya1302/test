<?php
// Include database configuration
require 'config.php';

// Function to manage users
function manageUsers($conn) {
    // Example logic for user management
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'];
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $role = $_POST['role'];

        // Insert user record into the database
        $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (:username, :password, :role)");
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $password);
        $stmt->bindParam(':role', $role);
        
        if ($stmt->execute()) {
            echo "User created successfully.";
        } else {
            echo "Error creating user.";
        }
    }
}

// Call the function to manage users
manageUsers($conn);
?>
