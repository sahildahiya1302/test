<?php
// Include database configuration
require 'config.php';

// Function to save health records
function saveHealthRecord($conn) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $student_id = $_POST['student_id'];
        $health_issue = $_POST['health_issue'];
        $vaccination_status = $_POST['vaccination_status'];
        $date = $_POST['date'];

        // Insert health record into the database
        $stmt = $conn->prepare("INSERT INTO health_records (student_id, health_issue, vaccination_status, date) VALUES (:student_id, :health_issue, :vaccination_status, :date)");
        $stmt->bindParam(':student_id', $student_id);
        $stmt->bindParam(':health_issue', $health_issue);
        $stmt->bindParam(':vaccination_status', $vaccination_status);
        $stmt->bindParam(':date', $date);
        
        if ($stmt->execute()) {
            echo "Health record saved successfully.";
        } else {
            echo "Error saving health record.";
        }
    }
}

// Call the function to save health records
saveHealthRecord($conn);
?>
