<?php
// Include database configuration
require 'config.php';

// Function to save student results
function saveResult($conn) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $student_id = $_POST['student_id'];
        $exam_name = $_POST['exam_name'];
        $subject = $_POST['subject'];
        $marks = $_POST['marks'];

        // Insert result record into the database
        $stmt = $conn->prepare("INSERT INTO results (student_id, exam_name, subject, marks) VALUES (:student_id, :exam_name, :subject, :marks)");
        $stmt->bindParam(':student_id', $student_id);
        $stmt->bindParam(':exam_name', $exam_name);
        $stmt->bindParam(':subject', $subject);
        $stmt->bindParam(':marks', $marks);
        
        if ($stmt->execute()) {
            echo "Result saved successfully.";
        } else {
            echo "Error saving result.";
        }
    }
}

// Call the function to save results
saveResult($conn);
?>
