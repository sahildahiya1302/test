<?php
session_start();
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $date = $_POST['date'];
    $student_id = $_POST['student_id'];
    $status = $_POST['status'];

    // Prepare and execute the SQL statement
    $stmt = $conn->prepare("INSERT INTO attendance (student_id, date, status) VALUES (:student_id, :date, :status)");
    $stmt->bindParam(':student_id', $student_id);
    $stmt->bindParam(':date', $date);
    $stmt->bindParam(':status', $status);

    if ($stmt->execute()) {
        echo "Attendance marked successfully.";
    } else {
        echo "Error marking attendance.";
    }
}
?>
