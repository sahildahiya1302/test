<?php
// Ad snippet to be inserted
$ad_snippet = '<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-1699807976756285" crossorigin="anonymous"></script>';

// Directory to scan for HTML files
$directory = "/home/u185229455/domains/todaylive.online/public_html/";

// Function to recursively find and update HTML files
function addAdSnippetToHTML($directory, $ad_snippet) {
    // Open the directory
    $files = scandir($directory);

    foreach ($files as $file) {
        // Skip . and ..
        if ($file === '.' || $file === '..') continue;

        $filePath = $directory . '/' . $file;

        // If it's a directory, recursively call this function
        if (is_dir($filePath)) {
            addAdSnippetToHTML($filePath, $ad_snippet);
        } elseif (pathinfo($filePath, PATHINFO_EXTENSION) === 'html') {
            // If it's an HTML file, process it
            $content = file_get_contents($filePath);

            // Check if the snippet is already present
            if (strpos($content, $ad_snippet) === false) {
                // Insert snippet before the closing </head> tag
                $updatedContent = str_replace('</head>', $ad_snippet . "\n</head>", $content);

                // Save the updated file
                file_put_contents($filePath, $updatedContent);
                echo "Updated: $filePath\n";
            } else {
                echo "Snippet already exists in: $filePath\n";
            }
        }
    }
}

// Call the function
addAdSnippetToHTML($directory, $ad_snippet);

echo "Ad snippet insertion completed.";
?>
