<?php
// Directory for storing articles
$outputDir = "/home/u185229455/domains/todaylive.online/public_html/";

// Function to generate a safe filename
function generateSafeFilename($title) {
    return preg_replace("/[^a-zA-Z0-9\-_]/", "", strtolower(substr($title, 0, 100)));
}

// Function to generate navigation links
function generateNavLinks($topics) {
    $navLinksHtml = '<nav><ul>';
    foreach ($topics as $topic) {
        $navLinksHtml .= '<li><a href="' . $topic . '.html">' . ucfirst($topic) . '</a></li>';
    }
    $navLinksHtml .= '<li><a href="index.html">Home</a></li></ul></nav>';
    return $navLinksHtml;
}

// Function to fetch recent articles for related articles section
function fetchRecentArticles($topic, $limit = 8) {
    global $outputDir;
    $topicFilePath = $outputDir . strtolower($topic) . ".html";

    if (!file_exists($topicFilePath)) {
        return [];
    }

    $topicHtml = file_get_contents($topicFilePath);
    $dom = new DOMDocument();
    @$dom->loadHTML($topicHtml);
    $xpath = new DOMXPath($dom);

    $articleCards = $xpath->query("//div[contains(@class, 'topic-article-card')]");
    $recentArticles = [];

    foreach ($articleCards as $card) {
        // Fetch the article link
        $link = $xpath->query(".//a/@href", $card)->item(0)->nodeValue;

        // Fetch the article image URL
        $image_url = $xpath->query(".//img/@src", $card)->item(0)->nodeValue;

        // Fetch the article title
        $title = $xpath->query(".//p", $card)->item(0)->nodeValue;

        // Fetch the keyword (assumes it's stored in a span or similar element)
        $keywordNode = $xpath->query(".//span[contains(@class, 'keyword')]", $card);
        $keyword = $keywordNode->length > 0 ? $keywordNode->item(0)->nodeValue : 'Unknown';

        // Fetch the time-ago (assumes it's stored in a span or similar element)
        $timeAgoNode = $xpath->query(".//span[contains(@class, 'time-ago')]", $card);
        $timeAgo = $timeAgoNode->length > 0 ? $timeAgoNode->item(0)->nodeValue : 'Just now';

        // Append the extracted data to the $recentArticles array
        $recentArticles[] = [
            'keyword' => $keyword,
            'title' => $title,
            'url' => $link,
            'image_url' => $image_url,
            'time_ago' => $timeAgo
        ];

        // Stop if the limit is reached
        if (count($recentArticles) >= $limit) {
            break;
        }
    }

    return $recentArticles;
}


// Function to save or update an article
function saveArticle($article, $outputDir) {
    $safeFilename = generateSafeFilename($article['title']);
    $filename = $safeFilename . ".html";
    $filepath = $outputDir . "/articles/" . $filename;

    // Fetch recent articles to show as related
    $relatedArticles = fetchRecentArticles($article['topic']);
    
    // Prepare related articles HTML
    $relatedArticlesHtml = "";
    foreach ($relatedArticles as $related) {
        $relatedArticlesHtml .= '
        <div class="related-article">
                <a href="/articles/' . generateSafeFilename($related['title']) . '.html">
                <img src="' . $related['image_url'] . '" alt="' . $related['title'] . '">
                <p>' . $related['title'] . '</p>
            </a>
        </div>';
    }

    // HTML template for the article
   $htmlTemplate = '
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="' . htmlspecialchars($article['title']) . '">
    <meta name="robots" content="index, follow">
    <meta name="keywords" content="' . htmlspecialchars($article['title']) . ', Tv-and-radio, Fashion, Food, Technology, Lifeandstyle, Global, Environment, Football, Us-news, News, Uk-news, Culture, Film, Money, Stage, Music, Media, Politics, General, Sport, Global-development, Artanddesign, Books, Travel, Business, World, Society">
    <meta property="og:title" content="' . htmlspecialchars($article['title']) . '">
    <meta property="og:description" content="' . htmlspecialchars($article['title']) . '">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="' . htmlspecialchars($article['title']) . '">
    <meta name="twitter:description" content="' . htmlspecialchars($article['title']) . '">
    <link rel="stylesheet" type="text/css" href="articlestyles.css">
    <title>' . htmlspecialchars($article['title']) . '</title>
</head>
<body>
    <header>
        <h1>Todaylive.Online</h1>
        <div class="nav">
            <nav>
                <ul>
<li><a href="https://todaylive.online/index.html">Home</a></li>
<li><a href="https://todaylive.online/tv-and-radio.html">Tv-and-radio</a></li>
<li><a href="https://todaylive.online/fashion.html">Fashion</a></li>
<li><a href="https://todaylive.online/food.html">Food</a></li>
<li><a href="https://todaylive.online/technology.html">Technology</a></li>
<li><a href="https://todaylive.online/lifeandstyle.html">Lifeandstyle</a></li>
<li><a href="https://todaylive.online/global.html">Global</a></li>
<li><a href="https://todaylive.online/environment.html">Environment</a></li>
<li><a href="https://todaylive.online/football.html">Football</a></li>
<li><a href="https://todaylive.online/us-news.html">Us-news</a></li>
<li><a href="https://todaylive.online/news.html">News</a></li>
<li><a href="https://todaylive.online/uk-news.html">Uk-news</a></li>
<li><a href="https://todaylive.online/culture.html">Culture</a></li>
<li><a href="https://todaylive.online/film.html">Film</a></li>
<li><a href="https://todaylive.online/money.html">Money</a></li>
<li><a href="https://todaylive.online/stage.html">Stage</a></li>
<li><a href="https://todaylive.online/music.html">Music</a></li>
<li><a href="https://todaylive.online/media.html">Media</a></li>
<li><a href="https://todaylive.online/politics.html">Politics</a></li>
<li><a href="https://todaylive.online/general.html">General</a></li>
<li><a href="https://todaylive.online/sport.html">Sport</a></li>
<li><a href="https://todaylive.online/global-development.html">Global-development</a></li>
<li><a href="https://todaylive.online/artanddesign.html">Artanddesign</a></li>
<li><a href="https://todaylive.online/books.html">Books</a></li>
<li><a href="https://todaylive.online/travel.html">Travel</a></li>
<li><a href="https://todaylive.online/business.html">Business</a></li>
<li><a href="https://todaylive.online/world.html">World</a></li>
<li><a href="https://todaylive.online/society.html">Society</a></li>

                </ul>
            </nav>
        </div>
    </header>

    <main>
        <div class="article-container">
            <article>
                
                <h1>' . htmlspecialchars($article['title']) . '</h1>
                <img src="' . htmlspecialchars($article['image_url']) . '" alt="Article Image">
                <span class="keyword"><span>' . $article['keyword'] . '</span></span>
                ' . $article['content'] . '
    <span class="time-ago" data-time="' . $currentDate . '">' . $timeAgoString . '</span> <!-- Time Ago -->
            </article>
            <aside>
                <h2>Related Articles</h2>
                <div class="related-articles">' . $relatedArticlesHtml . '</div>
            </aside>
        </div>
    </main>

    <footer class="footer">
        <div class="nav">
            <nav>
                <ul>
                   <li><a href="https://todaylive.online/index.html">Home</a></li>
<li><a href="https://todaylive.online/tv-and-radio.html">Tv-and-radio</a></li>
<li><a href="https://todaylive.online/fashion.html">Fashion</a></li>
<li><a href="https://todaylive.online/food.html">Food</a></li>
<li><a href="https://todaylive.online/technology.html">Technology</a></li>
<li><a href="https://todaylive.online/lifeandstyle.html">Lifeandstyle</a></li>
<li><a href="https://todaylive.online/global.html">Global</a></li>
<li><a href="https://todaylive.online/environment.html">Environment</a></li>
<li><a href="https://todaylive.online/football.html">Football</a></li>
<li><a href="https://todaylive.online/us-news.html">Us-news</a></li>
<li><a href="https://todaylive.online/news.html">News</a></li>
<li><a href="https://todaylive.online/uk-news.html">Uk-news</a></li>
<li><a href="https://todaylive.online/culture.html">Culture</a></li>
<li><a href="https://todaylive.online/film.html">Film</a></li>
<li><a href="https://todaylive.online/money.html">Money</a></li>
<li><a href="https://todaylive.online/stage.html">Stage</a></li>
<li><a href="https://todaylive.online/music.html">Music</a></li>
<li><a href="https://todaylive.online/media.html">Media</a></li>
<li><a href="https://todaylive.online/politics.html">Politics</a></li>
<li><a href="https://todaylive.online/general.html">General</a></li>
<li><a href="https://todaylive.online/sport.html">Sport</a></li>
<li><a href="https://todaylive.online/global-development.html">Global-development</a></li>
<li><a href="https://todaylive.online/artanddesign.html">Artanddesign</a></li>
<li><a href="https://todaylive.online/books.html">Books</a></li>
<li><a href="https://todaylive.online/travel.html">Travel</a></li>
<li><a href="https://todaylive.online/business.html">Business</a></li>
<li><a href="https://todaylive.online/world.html">World</a></li>
<li><a href="https://todaylive.online/society.html">Society</a></li>

                </ul>
            </nav>
        </div>

        <div id="footer-content">
            <ul class="footer__links">
                <li><a href="#">Help</a></li>
                <li><a href="#">Complaints & corrections</a></li>
                <li><a href="#">SecureDrop</a></li>
                <li><a href="#">Work for us</a></li>
            </ul>

            <ul class="footer__links">
                <li><a href="/info/privacy">Privacy policy</a></li>
                <li><a href="/info/cookies">Cookie policy</a></li>
                <li><a href="/help/terms-of-service">Terms & conditions</a></li>
                <li><a href="/help/contact-us">Contact us</a></li>
            </ul>

            <ul class="footer__social">
                <li><a href="#">All topics</a></li>
                <li><a href="#">All writers</a></li>
                <li><a href="#">Digital newspaper archive</a></li>
            </ul>

            <ul class="footer__social">
                <li><a href="#">Facebook</a></li>
                <li><a href="#">YouTube</a></li>
                <li><a href="#">Instagram</a></li>
                <li><a href="#">LinkedIn</a></li>
                <li><a href="#">X</a></li>
            </ul>
        </div>

        <div class="footer__support">
            <p>Support the Todaylive.Online</p>
            <a href="#">Support us</a>
            <a href="#">Contribute</a>
        </div>
        <div class="footer__copyright">
            © 2024 Todaylive.Online News & Media Limited or its affiliated companies. All rights reserved.
        </div>
    </footer>

   <script>
       function timeAgo(date) {
    const now = new Date();
    const diffInSeconds = Math.floor((now - new Date(date)) / 1000);
    const minutes = Math.floor(diffInSeconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (minutes < 1) return "Just now";
    if (minutes < 60) return minutes + " minute(s) ago";
    if (hours < 24) return hours + " hour(s) ago";
    return days + " day(s) ago";
}

// Select all elements with the class "time-ago" and update their text content
document.querySelectorAll(".time-ago").forEach((element) => {
    const date = element.dataset.time;
    element.textContent = timeAgo(date);
});

    </script>
</body>
</html>
';


    // Write the article HTML to a file
    if (file_put_contents($filepath, $htmlTemplate) === false) {
        echo "Failed to write file: $filepath";
    }
}



function updateTopicPage($outputDir, $topic, $newArticle) {
    // Step 1: Prepare the file path
    $filepath = $outputDir . strtolower(str_replace(' ', '', $topic)) . ".html";
    
    // Step 2: Generate the new article card HTML
    $currentDate = date('Y-m-d\TH:i:s\Z'); // Format as ISO 8601 (e.g., 2024-12-01T12:00:00Z)


  // Truncate the content to 200 words
$truncatedContent = implode(' ', array_slice(explode(' ', $newArticle['content']), 0, 400)) . '...';

    $newArticleCardHtml = '
    <div class="topic-article-card">
        <span class="keyword">' . htmlspecialchars($newArticle['keyword']) . '</span>
        <span class="time-ago" data-time="' . $currentDate . '">' . $timeAgoString . '</span>
        <a href="/articles/' . generateSafeFilename($newArticle['title']) . '.html">
            <img src="' . $newArticle['image_url'] . '" alt="' . htmlspecialchars($newArticle['title']) . '">
            <p>' . htmlspecialchars($newArticle['title']) . '</p>
        </a>
    </div>';

    // Step 3: Check if the file exists and read the existing content
    if (!file_exists($filepath)) {
        echo "File not found: $filepath";
        return;
    }

    $topicContent = file_get_contents($filepath);

    // Step 4: Find the `topic-article-cards` container
    $cardsContainerStart = strpos($topicContent, '<div class="topic-article-cards">');
    if ($cardsContainerStart === false) {
        echo "No container found for article cards.";
        return;
    }

    $cardsContainerEnd = strpos($topicContent, '</div>', $cardsContainerStart);
    if ($cardsContainerEnd === false) {
        echo "No closing tag for the article cards container.";
        return;
    }

    // Step 5: Insert the new article card at the top of the container
    $beforeContainer = substr($topicContent, 0, $cardsContainerStart + strlen('<div class="topic-article-cards">'));
    $insideContainer = substr($topicContent, $cardsContainerStart + strlen('<div class="topic-article-cards">'), $cardsContainerEnd - ($cardsContainerStart + strlen('<div class="topic-article-cards">')));
    $afterContainer = substr($topicContent, $cardsContainerEnd);

    // Prepend the new article card to the existing cards
    $updatedContent = $beforeContainer . "\n" . $newArticleCardHtml . $insideContainer . "\n" . $afterContainer;

    // Step 6: Write the updated content back to the file
    if (file_put_contents($filepath, $updatedContent) === false) {
        echo "Failed to update file: $filepath";
    } else {
        echo "Successfully updated topic page: $filepath";
    }
}






function updateIndexPage($outputDir, $topic, $newArticle) {
    $filepath = $outputDir . "/index.html";
    $articleSectionUpdated = false;
    $currentDate = date('Y-m-d\TH:i:s\Z'); // Format as ISO 8601 (e.g., 2024-12-01T12:00:00Z)


  // Truncate the content to 200 words
$truncatedContent = implode(' ', array_slice(explode(' ', $newArticle['content']), 0, 200)) . '...';

// Fetch all articles and create HTML snippet for the new article
    $newArticleHtml = '
<div class="article">
    <span class="time-ago" data-time="' . $currentDate . '">' . $timeAgoString . '</span> <!-- Time Ago -->
    <a href="/articles/' . generateSafeFilename($newArticle['title']) . '.html">
        <img src="' . $newArticle['image_url'] . '" alt="' . htmlspecialchars($newArticle['title']) . '">
        <div class="article-content">
            <span class="keyword">' . htmlspecialchars($newArticle['keyword']) . '</span> <!-- Keyword -->
            <h3>' . htmlspecialchars($newArticle['title']) . '</h3>
            <p>' . htmlspecialchars($truncatedContent) . '</p>
        </div>
    </a>
</div>';



    // Read the existing index.html content
    $indexContent = file_get_contents($filepath);

    // Normalize topic for class and h2 match
    $normalizedTopic = strtolower(str_replace(' ', '', $topic)); // Remove spaces and convert to lowercase

    // Look for the specific section for the topic by class and h2 text
    $pattern = '/<section class="category-block ' . preg_quote($normalizedTopic, '/') . '">\s*<h2>' . ucfirst($topic) . '<\/h2>\s*<div class="articles-container main-articles">(.*?)<\/div>/s';

    // Debugging: Output pattern and topic
    echo "<pre>Normalized Topic: $normalizedTopic</pre>";

    if (preg_match($pattern, $indexContent, $matches)) {
        // Debugging: Output matches
        echo "<pre>Matches Found:Yes</pre>";
        print_r($matches);

        // Insert the new article HTML at the beginning of the section
        $sectionHtml = $newArticleHtml . $matches[1];
        $updatedSection = str_replace($matches[1], $sectionHtml, $matches[0]);

        // Replace the entire section in the index content
        $indexContent = str_replace($matches[0], $updatedSection, $indexContent);
        $articleSectionUpdated = true;
    }

    // Write the updated index HTML back to the file
    if ($articleSectionUpdated) {
        if (file_put_contents($filepath, $indexContent) === false) {
            echo "Failed to update file: $filepath";
        }
    } else {
        echo "Topic section not found for the new article.";
    }
}


// Main logic for handling new article creation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $article = [
        'title' => $_POST['title'],
        'content' => $_POST['content'],
        'image_url' => $_POST['image_url'],
        'topic' => $_POST['topic'],
        'keyword' => $_POST['keyword']
        
    ];

    // Save the new article
    saveArticle($article, $outputDir);

    // Update the index page with the new article
    updateIndexPage($outputDir, $article['topic'], $article);

    // Update the topic page with the new article card
    updateTopicPage($outputDir, $article['topic'], $article);

    echo "Article and related pages updated successfully.";
} else {
    echo "Invalid request method.";
}
?>
